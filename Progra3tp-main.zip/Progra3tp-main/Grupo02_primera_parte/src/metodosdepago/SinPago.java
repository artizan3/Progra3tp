package metodosdepago;

import abonado.Abonado;

public class SinPago extends DecoratorPago{

	public SinPago(Abonado abonado) {
		super(abonado);
	}
	
	@Override
	public double valorDeTipoPago() {
		// TODO Auto-generated method stub
		return valorSinTipoPago();
	}

	@Override
	public String tipoDePago() {
		// TODO Auto-generated method stub
		return "Impago";
	}

}
