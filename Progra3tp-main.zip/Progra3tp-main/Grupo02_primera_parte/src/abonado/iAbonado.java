package abonado;

public interface iAbonado {

}
