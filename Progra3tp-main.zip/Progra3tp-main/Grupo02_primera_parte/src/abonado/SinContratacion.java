package abonado;

import java.time.LocalDate;

import empresa.Contratacion;
import empresa.Factura;
import excepciones.ContratacionInvalidaException;

public class SinContratacion implements IState {

	private Fisica abonado;
	
	
	
	public SinContratacion(Fisica abonado) {
		super();
		this.abonado = abonado;
	}

	@Override
	public void pagarFactura(Factura factura,LocalDate fechaDePago) {
		//No puede pagar ya que no contrato nada
		//Mensaje a traves de la ventana
	}

	@Override
	public void contratarServicio(Contratacion contrato) {
		abonado.aniadirContratacion(contrato);
		abonado.setEstado(new ConContratacion(this.abonado));
	}

	@Override
	public void bajarServicio(Contratacion contrato) throws ContratacionInvalidaException {
		//No puede bajar servicio ya que no contrato nada
		//Mensaje a traves de la ventana
	}
	
	//Este metodo se llama 1 vez al mes
	
	public void chequeaMes() {
	   int i = 0, j = 0;
			
		while (i < 2 && j < abonado.listaDeFacturas.size()) {
		   if (!abonado.listaDeFacturas.get(j).isPago())
			   i++;
		   j++;   
		}  
		if (j > 0)
		   if (i >= 2) {
			  abonado.setEstado(new Moroso(abonado));
		      abonado.setRecargo(1.3);
		   }
		   else {
			   abonado.setEstado(new ConContratacion(abonado));
			   abonado.setRecargo(1);
		   }
			   
    }

}
