package excepciones;

@SuppressWarnings("serial")
public class DomicilioVinculadoException extends Exception {

}
