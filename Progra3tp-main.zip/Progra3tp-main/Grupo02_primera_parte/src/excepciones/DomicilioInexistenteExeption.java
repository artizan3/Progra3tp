package excepciones;

public class DomicilioInexistenteExeption extends Exception {

}
