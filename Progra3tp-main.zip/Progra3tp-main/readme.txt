integrantes GRUPO 2:
Bruno Trinitario
Alan Juares
Juan Basualdo
Juan Olave